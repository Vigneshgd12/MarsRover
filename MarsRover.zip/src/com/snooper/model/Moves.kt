package com.snooper.model

enum class Moves(Moves: String) {
    L("Left turn"), R("Right turn"), M("Move forward")
}