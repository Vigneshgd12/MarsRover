package com.snooper.model

enum class Direction(val direction: String) {
    N("North"), S("South"), W("West"), E("East");

}